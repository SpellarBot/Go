package sphinx

import (
	_ "github.com/yunge/sphinx"
)
