package core

import "testing"

func TestCreateOSSBucket(t *testing.T) {
	CreateOSSBucket("test")
}
