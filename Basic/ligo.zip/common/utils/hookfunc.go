package utils

type HookFunc func() error
