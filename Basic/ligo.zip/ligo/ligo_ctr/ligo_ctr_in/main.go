package main

import (
	_ "vidmate.com/ligo/ligo_ctr/common/routers"
	"vidmate.com/ligo/ligo_ctr/common/controllers"
	"github.com/astaxie/beego"
)

func main() {
	beego.AddAPPStartHook(controllers.GlobalInit)
	go controllers.Consumer()
	beego.Run()
	select{}
}