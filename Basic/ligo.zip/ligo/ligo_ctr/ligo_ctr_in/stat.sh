#!/bin/bash

# 输出概要

PORT=6571

curl "http://127.0.0.1:${PORT}/get_detail"